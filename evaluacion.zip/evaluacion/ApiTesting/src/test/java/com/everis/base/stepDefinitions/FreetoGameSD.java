package com.everis.base.stepDefinitions;

import com.everis.base.ServicioCore;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class FreetoGameSD {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ServicioSD.class);
    @Steps
    private ServicioCore servicioCore;

    @Given("la URL_BASE {string}")
    public void laURL_BASE(String urlBase) {
        LOGGER.info("i laURL_BASEDelServicioEs");
        LOGGER.info("URL BASE = " + urlBase);
        servicioCore.configurarURLBaseServicio(urlBase);
        LOGGER.info("f laURL_BASEDelServicioEs");
    }

    @Given("la URL_BASE de Servicio responde {int}")
    public void laURL_BASEDeServicioResponde(int codigoRespuestaEsperado) {
        LOGGER.info("i laURL_BASEDelServicioResponde");
        LOGGER.info("Consulta la Disponibilidad del Servicio ... ");
        servicioCore.consultarServicioDisponibilidad(null);
        servicioCore.validarCodigoEsperado(codigoRespuestaEsperado);
        LOGGER.info("f laURL_BASEDelServicioResponde");
    }

    @When("consulto el Servicio del Path {string}")
    public void consultoElServicioDelPath(String path) {
        LOGGER.info("i consultoElServicioConElPath");
        servicioCore.consultarServicioGet(null, path);
        LOGGER.info("f consultoElServicioConElPath");
    }

    @Then("el codigo de la respuesta es {int}")
    public void elCodigoDeLaRespuestaEs(int codigoRespuestaEsperado) {
            LOGGER.info("i elCodigoDeRespuestaEs");
            servicioCore.validarCodigoEsperado(codigoRespuestaEsperado);
            LOGGER.info("f elCodigoDeRespuestaEs");
    }

    @And("valido el  resultado final")
    public void validoElResultadoFinal() {
        servicioCore.validaRespuesta();
    }



}
